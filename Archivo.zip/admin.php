<?php session_start();
        require_once($_SERVER["DOCUMENT_ROOT"]."/config.php");

        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        if (isset($_SESSION["UserId"])) {
                header('Location: /panel/perfil?msg=yal');
                exit();
            } 

?>
<!DOCTYPE html>
<html lang="en">
<?php
$title = 'Inicio';
$inicio = 'current';
include('includes/head.php');
?>

<body>
    <?php
    include("includes/preloader.php");
    ?>
    <div id="wrapper">
        <?php
        include("includes/header.php");
        include("admin/login.php");
        include("includes/footer.php");
        include("includes/scripts.php");
        ?>
    </div>
</body>

</html>