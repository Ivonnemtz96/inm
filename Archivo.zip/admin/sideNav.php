<div class="col-md-4">
    <div class="sidebar left">

        <div class="my-account-nav-container">

            <ul class="my-account-nav">
                <li class="sub-nav-title">Perfil</li>
                <li><a href="profile.php"><i class="fa fa-user"></i> Editar perfil</a></li>
            </ul>

            <ul class="my-account-nav">
                <li class="sub-nav-title">Configuración</li>
                <li><a href="caracteristicas.php"><i class="fa fa-check"></i> Carácteristicas</a></li>
                <li><a href="agregar-caracteristica.php"><i class="fa fa-pencil"></i> Enviar carácteristica</a></li>
            </ul>

            <ul class="my-account-nav">
                <li class="sub-nav-title">Propiedades</li>
                <li><a href="propiedades.php"><i class="fa fa-home"></i> Mis propiedades</a>


                </li>
                <li><a href="agregar-propiedades.php"><i class="fa fa-pencil"></i> Enviar propiedad</a></li>
            </ul>

            <ul class="my-account-nav">
                <li><a href="/cerrar"><i class="sl sl-icon-power"></i> Salir</a></li>
            </ul>

        </div>

    </div>
</div>