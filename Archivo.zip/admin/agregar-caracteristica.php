<!-- Titlebar
================================================== -->
<div id="titlebar" class="submit-page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><i class="fa fa-plus-circle"></i> Agregar característica</h2>
            </div>
        </div>
    </div>
</div>


<!-- Content
================================================== -->
<div class="container">
    <div class="row">
        <!-- Submit Page -->
        <!-- Widget -->
        <?php 
        include("admin/sideNav.php");
        ?>
        <div class="col-md-8">
            <div class="submit-page">


                <!-- Section -->
                <h3>Contact Details</h3>
                <div class="submit-section">

                    <!-- Row -->
                    <div class="row with-forms">

                        <!-- Name -->
                        <div class="col-md-4">
                            <h5>Carácteristica</h5>
                            <input type="text">
                        </div>

                    </div>
                    <!-- Row / End -->
                </div>
                <!-- Section / End -->
                <div class="divider"></div>
                <a href="#" class="button preview margin-top-5">Preview <i class="fa fa-arrow-circle-right"></i></a>

            </div>
        </div>

    </div>
</div>